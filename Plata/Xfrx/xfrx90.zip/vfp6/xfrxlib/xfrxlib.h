
* XFRX system constantes
#DEFINE __xfrxlib_tlb_Disable -1
#DEFINE __xfrxlib_tlb_Hide     0
#DEFINE __xfrxlib_tlb_Show     1

#DEFINE __xfrxlib_Book_Disable -1
#DEFINE __xfrxlib_Book_Hide     0
#DEFINE __xfrxlib_Book_Show     1
#DEFINE __xfrxlib_Book_Auto     2

#DEFINE __xfrxlib_DM_Disable -1
#DEFINE __xfrxlib_DM_Hide     0
#DEFINE __xfrxlib_DM_Show     1

#DEFINE __xfrxlib_Prop_Disable -1
#DEFINE __xfrxlib_Prop_Hide     0
#DEFINE __xfrxlib_Prop_Show     1


#DEFINE __xfrxlib_UI_tlb    0
#DEFINE __xfrxlib_UI_html   1
#DEFINE __xfrxlib_UI_menu   2
#DEFINE __xfrxlib_UI_status 3



* XFRX langugae constantes
#DEFINE __xfrxlib_NotFound "Not Found"

* Tooltipes
#DEFINE __xfrxlib_Bookmark_ttt "Show/hide bookmark panel"
#DEFINE __xfrxlib_FirstP_ttt   "Go first page"
#DEFINE __xfrxlib_LastP_ttt    "Go last page"
#DEFINE __xfrxlib_PrevP_ttt    "Skip to preview page"
#DEFINE __xfrxlib_NextP_ttt    "Skip to next page"
#DEFINE __xfrxlib_Print_ttt    "Print report..."
#DEFINE __xfrxlib_Find_ttt     "Show find dialog"
#DEFINE __xfrxlib_Quit_ttt     "Quit report preview"
#DEFINE __xfrxlib_Zoom_ttt     "Set zoom"
#DEFINE __xfrxlib_PageDisp_ttt "Active page %Start% of %End%"
#DEFINE __xfrxlib_DM_ttt       "Design Mode"
#DEFINE __xfrxlib_Prop_ttt     "Object properties"
#DEFINE __xfrxlib_Page_ttt     "Go to page..."
#DEFINE __xfrxlib_Save_ttt     "Save changes"

#DEFINE __xfrxlib_Picture  "Picture"
#DEFINE __xfrxlib_Page  "Page "

#DEFINE __xfrxlib_Cursor_ttt    "Cursor"
#DEFINE __xfrxlib_Label_ttt     "Label"
#DEFINE __xfrxlib_Image_ttt     "Image"
#DEFINE __xfrxlib_Shape_ttt     "Shape"
#DEFINE __xfrxlib_Hyperlink_ttt "Hyperlink"
#DEFINE __xfrxlib_Line_ttt      "Line"


* Zoom values
#DEFINE __xfrxlib_Zoom_300 "300%"
#DEFINE __xfrxlib_Zoom_200 "200%"
#DEFINE __xfrxlib_Zoom_175 "175%"
#DEFINE __xfrxlib_Zoom_150 "150%"
#DEFINE __xfrxlib_Zoom_125 "125%"
#DEFINE __xfrxlib_Zoom_100 "100%"
#DEFINE __xfrxlib_Zoom_75  " 75%"
#DEFINE __xfrxlib_Zoom_50  " 50%"
#DEFINE __xfrxlib_Zoom_25  " 25%"
#DEFINE __xfrxlib_Zoom_10  " 10%"
#DEFINE __xfrxlib_Zoom_FWd "Fit Width"
#DEFINE __xfrxlib_Zoom_FWi "Fit in Window"

* Menu
#DEFINE __xfrxlib_Book_prm "Bookmark"
#DEFINE __xfrxlib_Book_stt __xfrxlib_Bookmark_ttt
#DEFINE __xfrxlib_Quit_prm "Quit"
#DEFINE __xfrxlib_Quit_stt __xfrxlib_Quit_ttt
#DEFINE __xfrxlib_Zoom_prm "Zoom"
#DEFINE __xfrxlib_Zoom_stt __xfrxlib_Zoom_ttt
#DEFINE __xfrxlib_Find_prm "Find..."
#DEFINE __xfrxlib_Find_stt __xfrxlib_Find_ttt
#DEFINE __xfrxlib_Print_prm "Print..."
#DEFINE __xfrxlib_Print_stt __xfrxlib_Print_ttt
#DEFINE __xfrxlib_Go_prm "Go"
#DEFINE __xfrxlib_Go_stt "Go to page"
#DEFINE __xfrxlib_GoToPage_prm "Go to page..."
#DEFINE __xfrxlib_GoToPage_stt "Go to page..."
#DEFINE __xfrxlib_Toolbar_prm "Toolbar"
#DEFINE __xfrxlib_Toolbar_stt "Show/hide report preview toolbar"

#DEFINE __xfrxlib_FirstP_prm   "First"
#DEFINE __xfrxlib_FirstP_stt   __xfrxlib_FirstP_ttt
#DEFINE __xfrxlib_LastP_prm    "Last"
#DEFINE __xfrxlib_LastP_stt    __xfrxlib_LastP_ttt
#DEFINE __xfrxlib_PrevP_prm    "Preview"
#DEFINE __xfrxlib_PrevP_stt    __xfrxlib_PrevP_ttt
#DEFINE __xfrxlib_NextP_prm    "Next"
#DEFINE __xfrxlib_NextP_stt    __xfrxlib_NextP_ttt

#DEFINE __xfrxlib_Zoom_300_prm __xfrxlib_Zoom_300
#DEFINE __xfrxlib_Zoom_300_stt "Zoom to 300%"
#DEFINE __xfrxlib_Zoom_200_prm __xfrxlib_Zoom_200
#DEFINE __xfrxlib_Zoom_200_stt "Zoom to 200%"
#DEFINE __xfrxlib_Zoom_175_prm __xfrxlib_Zoom_175
#DEFINE __xfrxlib_Zoom_175_stt "Zoom to 175%"
#DEFINE __xfrxlib_Zoom_150_prm __xfrxlib_Zoom_150
#DEFINE __xfrxlib_Zoom_150_stt "Zoom to 150%"
#DEFINE __xfrxlib_Zoom_125_prm __xfrxlib_Zoom_125
#DEFINE __xfrxlib_Zoom_125_stt "Zoom to 125%"
#DEFINE __xfrxlib_Zoom_100_prm __xfrxlib_Zoom_100
#DEFINE __xfrxlib_Zoom_100_stt "Zoom to 100%"
#DEFINE __xfrxlib_Zoom_75_prm  __xfrxlib_Zoom_75
#DEFINE __xfrxlib_Zoom_75_stt  "Zoom to 75%"
#DEFINE __xfrxlib_Zoom_50_prm  __xfrxlib_Zoom_50
#DEFINE __xfrxlib_Zoom_50_stt  "Zoom to 50%"
#DEFINE __xfrxlib_Zoom_25_prm  __xfrxlib_Zoom_25
#DEFINE __xfrxlib_Zoom_25_stt  "Zoom to 25%"
#DEFINE __xfrxlib_Zoom_10_prm  __xfrxlib_Zoom_10
#DEFINE __xfrxlib_Zoom_10_stt  "Zoom to 10%"
#DEFINE __xfrxlib_Zoom_FWd_prm __xfrxlib_Zoom_FWd
#DEFINE __xfrxlib_Zoom_FWd_stt "Fit Width"
#DEFINE __xfrxlib_Zoom_FWi_prm __xfrxlib_Zoom_FWi
#DEFINE __xfrxlib_Zoom_FWi_stt "Fit in Window"


#DEFINE CRLF CHR(13)+CHR(10)

*********************************
*
*********************************

#DEFINE __xfrxlib_None_val      0
#DEFINE __xfrxlib_Book_val      2
#DEFINE __xfrxlib_Quit_val      1
#DEFINE __xfrxlib_Find_val      3
#DEFINE __xfrxlib_Print_val     4
#DEFINE __xfrxlib_Toolbar_val   7
#DEFINE __xfrxlib_GoToPage_val  8

#DEFINE __xfrxlib_FirstP_val   51
#DEFINE __xfrxlib_PrevP_val    52
#DEFINE __xfrxlib_NextP_val    53
#DEFINE __xfrxlib_LastP_val    54

#DEFINE __xfrxlib_Zoom_300_val 61
#DEFINE __xfrxlib_Zoom_200_val 62
#DEFINE __xfrxlib_Zoom_175_val 63
#DEFINE __xfrxlib_Zoom_150_val 64
#DEFINE __xfrxlib_Zoom_125_val 65
#DEFINE __xfrxlib_Zoom_100_val 66
#DEFINE __xfrxlib_Zoom_75_val  67
#DEFINE __xfrxlib_Zoom_50_val  68
#DEFINE __xfrxlib_Zoom_25_val  69
#DEFINE __xfrxlib_Zoom_10_val  70
#DEFINE __xfrxlib_Zoom_FWd_val 71
#DEFINE __xfrxlib_Zoom_FWi_val 72


#DEFINE _xfrx_prop_Name   "Name"
#DEFINE _xfrx_prop_Value  "Value"


#DEFINE _xfrx_Mode_None            0
#DEFINE _xfrx_Mode_MoveObject      1
#DEFINE _xfrx_Mode_MoveSheet       3
#DEFINE _xfrx_Mode_ROL             4
#DEFINE _xfrx_Mode_ROT             5
#DEFINE _xfrx_Mode_ROR             6
#DEFINE _xfrx_Mode_ROB             7
#DEFINE _xfrx_Mode_SelectObjectes  8
#DEFINE _xfrx_Mode_NewObject       9
#DEFINE _xfrx_Mode_MoveSheetTimer 10

****************************
#DEFINE _xfrx_ROP_A    0 && All
#DEFINE _xfrx_ROP_L    1 && Left
#DEFINE _xfrx_ROP_T    2 && Top
#DEFINE _xfrx_ROP_W    4 && Width
#DEFINE _xfrx_ROP_H    8 && Height


* ID classes
#DEFINE _xfrxrectangle   1
#DEFINE _xfrxline        2
#DEFINE _xfrxlabel       8
#DEFINE _xfrximage      16
#DEFINE _xfrxhyperlink  32


#DEFINE _xfrxrectangle_c   "xfrxrectangle"
#DEFINE _xfrxline_c        "xfrxline"
#DEFINE _xfrxlabel_c       "xfrxlabel"
#DEFINE _xfrximage_c       "xfrximage"
#DEFINE _xfrxhyperlink_c   "xfrxhyperlink"
